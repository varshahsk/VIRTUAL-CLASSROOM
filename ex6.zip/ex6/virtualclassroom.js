const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();  
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));  



mongoose.connect('mongodb://localhost:27017/virtual', { useNewUrlParser: true, useUnifiedTopology: true });

const ClassroomModel = mongoose.model('Classroom', {
  name: String,
  students: [{ name: String, id: String }],
});

const UserModel = mongoose.model('User', {
  id: String,
  name: String,
  password: String,
  userType: String,
});
app.post('/signup', async (req, res) => {
  try {
    const { id, name, password, userType } = req.body;

 
    const existingUser = await UserModel.findOne({ id });

    if (existingUser) {
      return res.send('User already exists.');
    }

  
    const user = new UserModel({ id, name, password, userType });
    await user.save();

    console.log(`User "${name}" with ID "${id}" has been registered.`);

   
    console.log('Redirecting to /login');

    res.redirect('/login');  
  } catch (error) {
    console.error('Error signing up:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/login', async (req, res) => {
  try {
    const { id, password, userType } = req.body;

    console.log('Received login request:', { id, password, userType });


    const user = await UserModel.findOne({ id, password, userType });

    console.log('User found in the database:', user);

    if (!user) {
      return res.send('Invalid credentials. Please check your ID, password, and user type.');
    }

   
    console.log(`User "${user.name}" with ID "${user.id}" logged in.`);

    res.redirect('/addClassroom');
  } catch (error) {
    console.error('Error logging in:', error.message);
    res.status(500).send('Internal Server Error');
  }
});


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, 'uploads');
    
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath);
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage });

app.post('/uploadAssignment', upload.single('assignmentFile'), (req, res) => {
  res.send('File uploaded successfully.');
});




app.get('/', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});

app.get('/manageClassroom', (req, res) => {
  const filePath = path.join(__dirname, 'manageClassroom.html');
  console.log('Resolved file path:', filePath);
  res.sendFile(filePath, (err) => {
    if (err) {
      console.error('Error sending file:', err);
      res.status(500).send('Internal Server Error');
    }
  });
});

app.post('/addStudent', async (req, res) => {
  try {
    const { className, studentName, studentId } = req.body;

    console.log('Received request to add student:', { className, studentName, studentId });

    let classroom = await ClassroomModel.findOne({ name: className });

    if (!classroom) {
     
      classroom = new ClassroomModel({ name: className, students: [] });
    }

    
    const existingStudent = classroom.students.find(student => student.id === studentId);

    if (existingStudent) {
      return res.send(`Student "${studentName}" with ID "${studentId}" already exists in classroom "${className}".`);
    }

  
    classroom.students.push({ name: studentName, id: studentId });
    await classroom.save();

    console.log(`Student "${studentName}" with ID "${studentId}" has enrolled in classroom "${className}".`);

    console.log('Updated classroom:', classroom);

    res.send(`Student "${studentName}" with ID "${studentId}" has enrolled in classroom "${className}".`);
  } catch (error) {
    console.error('Error adding student:', error.message);
    res.status(500).send('Internal Server Error');
  }
});



app.post('/removeStudent', async (req, res) => {
  try {
    const { className, studentName } = req.body;

    console.log('Received request to remove student:', { className, studentName });

    const classroom = await ClassroomModel.findOne({ name: className });

    if (!classroom) {
      console.log(`Classroom "${className}" not found.`);
      return res.status(404).send(`Classroom "${className}" not found.`);
    }

    
    classroom.students = classroom.students.filter(student => student.name !== studentName);
    await classroom.save();

    console.log(`Student "${studentName}" has been removed from classroom "${className}".`);
    res.send(`Student "${studentName}" has been removed from classroom "${className}".`);
  } catch (error) {
    console.error('Error removing student:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/listStudents', async (req, res) => {
  try {
    const className = req.query.className;

    console.log('Received request to list students in classroom:', { className });

    const classroom = await ClassroomModel.findOne({ name: className });

    if (!classroom) {
      console.log(`Classroom "${className}" not found.`);
      return res.status(404).send(`Classroom "${className}" not found.`);
    }

    
    const students = classroom.students.map(student => `${student.name} (ID: ${student.id})`);
    console.log(`Students in classroom "${className}":`, students);
    res.send(`Students in classroom "${className}":\n${students.join('\n')}`);
  } catch (error) {
    console.error('Error listing students:', error.message);
    res.status(500).send('Internal Server Error');
  }
});
app.get('/addClassroom', (req, res) => {
  res.sendFile(__dirname + '/i.html');
});




app.post('/addClassroom', async (req, res) => {
  try {
    const { className } = req.body;

   
    const existingClassroom = await ClassroomModel.findOne({ name: className });

    if (!existingClassroom) {
      const classroom = new ClassroomModel({ name: className, students: [] });
      await classroom.save();

      console.log(`Classroom "${className}" has been created.`);
      res.send(`Classroom "${className}" has been created.`);
    } else {
      console.log(`Classroom "${className}" already exists.`);
      res.send(`Classroom "${className}" already exists.`);
    }
  } catch (error) {
    console.error('Error adding classroom:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/listClassrooms', async (req, res) => {
  try {
    const classrooms = await ClassroomModel.find();
    console.log('Existing Classrooms:', classrooms.map(c => c.name));
    res.send('Existing Classrooms:\n' + classrooms.map(c => c.name).join('\n'));
  } catch (error) {
    console.error('Error listing classrooms:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/removeClassroom', async (req, res) => {
  try {
    const { className } = req.body;
    const result = await ClassroomModel.deleteOne({ name: className });

    if (result.deletedCount === 1) {
      console.log(`Classroom "${className}" has been removed.`);
      res.send(`Classroom "${className}" has been removed.`);
    } else {
      console.log(`Classroom "${className}" not found.`);
      res.send(`Classroom "${className}" not found.`);
    }
  } catch (error) {
    console.error('Error removing classroom:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
