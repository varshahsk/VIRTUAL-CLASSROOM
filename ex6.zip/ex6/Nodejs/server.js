const express = require('express');
const path = require('path');

const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost:27017/quizDB', { useNewUrlParser: true, useUnifiedTopology: true });

const quizSchema = new mongoose.Schema({
  q1_option: String,
  q2_option: String,
  q3_option: String,
  q4_option: String,
  q5_option: String,
  score: Number
});

const Quiz = mongoose.model('Quiz', quizSchema);
app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html');
});
app.post('/submit', function(req, res) {
  const q1_option = req.body.q1_option;
  const q2_option = req.body.q2_option;
  const q3_option = req.body.q3_option;
  const q4_option = req.body.q4_option;
  const q5_option = req.body.q5_option;
  let score = 0;

  if (q1_option === 'a') {
    score += 1;
  }

  if (q2_option === 'b') {
    score += 1;
  }

  if (q3_option === 'a') {
    score += 1;
  }
  if (q4_option === 'c') {
    score += 1;
  }
  if (q5_option === 'a') {
    score += 1;
  }
  const quiz = new Quiz({
    q1_option: q1_option,
    q2_option: q2_option,
    q3_option: q3_option,
    q4_option: q4_option,
    q5_option: q5_option,
    score: score
  });

  quiz.save(function(err) {
    if (err) {
      res.send(err);
    } else {
      res.render('score', { score: score });
    }
  });
});


app.listen(3000, function() {
  console.log('Server started on port 3000');
});
